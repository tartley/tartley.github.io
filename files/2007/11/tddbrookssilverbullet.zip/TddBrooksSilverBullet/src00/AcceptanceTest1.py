  
from unittest import makeSuite, TestCase, TextTestRunner

class AcceptanceTest1(TestCase):
    """Tests the program ImageResize during normal behaviour"""

    def testResizeALargeImage(self):
        # The user invokes ImageResize on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ImageResize.py TestData\big.jpg

        # The file big.jpg should be scaled down to 800x600

        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.

        self.fail("Test not written yet")


if __name__ == "__main__":
    suite = makeSuite(AcceptanceTest1)
    TextTestRunner().run(suite)
