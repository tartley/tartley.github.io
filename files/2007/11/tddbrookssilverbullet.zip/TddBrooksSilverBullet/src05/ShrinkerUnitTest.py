
from unittest import makeSuite, TestCase, TextTestRunner
from Shrinker import Shrinker

class ShrinkerUnitTest(TestCase):

    def testCalcNewSizeShouldShrinkTo800x600(self):
        expectedResults = [
             # initial       # expected
            ((32000, 24000), (800, 600)),
            ((1600, 1200),   (800, 600)),
            ((1600, 1000),   (800, 500)),
            ((1600, 2),      (800, 1)),
            ((1400, 1200),   (700, 600)),
            ((2, 1200),      (1, 600)),
            ((800, 600),     (800, 600)),
            ((400, 300),     (400, 300)),
            ((801, 600),     (800, 599)),
            ((800, 601),     (799, 600)),
            ((801, 601),     (800, 600)),
            ((799, 600),     (799, 600)),
            ((800, 599),     (800, 599)),
            ((799, 599),     (799, 599)),
            ((1, 1),         (1, 1)),
            ((0, 0),         (0, 0)),
        ]
        shrinker = Shrinker()
        for initialSize, expectedSize in expectedResults:

            newSize = shrinker.calcNewSize(initialSize)

            self.assertEquals(newSize, expectedSize,
                "size %s->%s, expected %s" % (
                    initialSize, newSize, expectedSize)
                )        


if __name__ == "__main__":
    suite = makeSuite(ShrinkerUnitTest)
    TextTestRunner().run(suite)
