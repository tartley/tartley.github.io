 
from os import path
from subprocess import check_call
from time import time
from unittest import makeSuite, TestCase, TextTestRunner
from PIL import Image, ImageChops
from TestUtils import imagesAreEqual

class AcceptanceTest1(TestCase):
    """Tests the program ImageResize during normal behaviour"""

    def invokeImageResize(self, filename):
        commandLine = "python ImageResize.py TestData\\%s" % filename
        check_call(commandLine.split())


    def assertImageHasBeenResized(self, filename, expectedSize):
        img = Image.open("TestData\\%s" % filename)
        self.assertEqual(img.size, expectedSize,
                         "image %s not resized correctly" % filename)

        expectedFilename = "TestData\\expectedResults\\%s" % filename
        expectedImg = Image.open(expectedFilename)
        self.assertTrue(imagesAreEqual(img, expectedImg),
                        "scaled image %s looks wrong" % filename)


    # I'll move the above functions to TestUtils.py


    def testResizeALargeImage(self):
        # The user invokes ImageResize on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ImageResize.py TestData\big.jpg
        self.invokeImageResize("big.jpg")

        # The file big.jpg should be scaled down to 800x600
        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.
        self.assertImageHasBeenResized("big.jpg", (800, 600))


    def testResizeAWideImage(self):
        # ImageResize is run on a wide image (1600x240 pixels)
        self.invokeImageResize("wide.jpg")
        # the wide image is scaled to be 800x120
        # and it has been scaled by cubic interpolation
        self.assertImageHasBeenResized("wide.jpg", (800, 120))


    def testResizeATallImage(self):
        # ImageResize is run on a very tall image (320x1200 pixels)
        self.invokeImageResize("tall.jpg")
        # the tall image is scaled to be 160x600
        # and it has been scaled by cubic interpolation
        self.assertImageHasBeenResized("tall.jpg", (160, 600))


    def testSmallImagesShouldNotBeResized(self):
        # ImageResize is run on a file of exactly 800x600 pixels
        self.invokeImageResize("medium.jpg")

        # this image should not have been resized at all
        # (its dateStamp should be older than a minute ago)
        lastModified = path.getmtime("TestData\\medium.jpg")
        self.assertTrue(time() - lastModified > 60,
                        "file should not have been modified")


# problem: testData files get overwritten by each test method


if __name__ == "__main__":
    suite = makeSuite(AcceptanceTest1)
    TextTestRunner().run(suite)
