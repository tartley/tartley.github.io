 
from os import listdir, path
from shutil import copy
from time import time
from unittest import makeSuite, TestCase, TextTestRunner
from TestUtils import (
    assertImageHasBeenResized, imagesAreEqual, invokeImageResize
)

class AcceptanceTest1(TestCase):
    """Tests the program ImageResize during normal behaviour"""

    def setUp(self):
        # restore TestData files from the 'originals' subdirectory
        for filename in listdir("TestData\\originals"):
            if filename != '.svn':
                copy("TestData\\originals\\" + filename, "TestData")
        

    def tearDown(self):
        pass


    def testResizeALargeImage(self):
        # The user invokes ImageResize on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ImageResize.py TestData\big.jpg
        invokeImageResize("big.jpg")

        # The file big.jpg should be scaled down to 800x600
        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.
        assertImageHasBeenResized(self, "big.jpg", (800, 600))


    def testResizeAWideImage(self):
        # ImageResize is run on a wide image (1600x240 pixels)
        invokeImageResize("wide.jpg")
        # the wide image is scaled to be 800x120
        # and it has been scaled by cubic interpolation
        assertImageHasBeenResized(self, "wide.jpg", (800, 120))


    def testResizeATallImage(self):
        # ImageResize is run on a very tall image (320x1200 pixels)
        invokeImageResize("tall.jpg")
        # the tall image is scaled to be 160x600
        # and it has been scaled by cubic interpolation
        assertImageHasBeenResized(self, "tall.jpg", (160, 600))


    def testSmallImagesShouldNotBeResized(self):
        # ImageResize is run on a file of exactly 800x600 pixels
        invokeImageResize("medium.jpg")

        # this image should not have been resized at all
        # (its dateStamp should be older than a minute ago)
        lastModified = path.getmtime("TestData\\medium.jpg")
        self.assertTrue(time() - lastModified > 60,
                        "file should not have been modified")


if __name__ == "__main__":
    suite = makeSuite(AcceptanceTest1)
    TextTestRunner().run(suite)
