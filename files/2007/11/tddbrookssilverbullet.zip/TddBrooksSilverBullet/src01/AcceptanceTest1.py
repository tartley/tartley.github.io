  
from subprocess import check_call
from unittest import makeSuite, TestCase, TextTestRunner
from PIL import Image
from TestUtils import imagesAreEqual

class AcceptanceTest1(TestCase):
    """Tests the program ImageResize during normal behaviour"""

    def testResizeALargeImage(self):
        # The user invokes ImageResize on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ImageResize.py TestData\big.jpg
        commandLine = "python ImageResize.py TestData\\big.jpg"
        check_call(commandLine.split())

        # The file big.jpg should be scaled down to 800x600
        img = Image.open("TestData\\big.jpg")
        self.assertEqual(img.size, (800, 600),
                         "image not resized correctly")

        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.
        expectedImg = Image.open("TestData\\expectedResults\\big.jpg")
        self.assertTrue(imagesAreEqual(img, expectedImg),
                        "scaled image looks wrong")

        # this test method is finished, so the self.fail()
        # has now been removed


# Run this - it's important to see your tests fail
# next: Add further test methods, derived from your specification

if __name__ == "__main__":
    suite = makeSuite(AcceptanceTest1)
    TextTestRunner().run(suite)
