
from PIL import ImageChops

def imagesAreEqual(img1, img2):
    """Returns True if img1 and img2 have identical pixel values"""
    difference = ImageChops.difference(img1, img2)
    for rgb in difference.getdata():
        if rgb != (0, 0, 0):
            return False
    return True
