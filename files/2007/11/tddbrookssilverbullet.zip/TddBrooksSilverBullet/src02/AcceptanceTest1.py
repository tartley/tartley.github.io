  
from subprocess import check_call
from unittest import makeSuite, TestCase, TextTestRunner
from PIL import Image, ImageChops
from TestUtils import imagesAreEqual

class AcceptanceTest1(TestCase):
    """Tests the program ImageResize during normal behaviour"""

    def testResizeALargeImage(self):
        # The user invokes ImageResize on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ImageResize.py TestData\big.jpg
        commandLine = "python ImageResize.py TestData\\big.jpg"
        check_call(commandLine.split())

        # The file big.jpg should be scaled down to 800x600
        img = Image.open("TestData\\big.jpg")
        self.assertEqual(img.size, (800, 600),
                         "image not resized correctly")

        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.
        expectedImg = Image.open("TestData\\expectedResults\\big.jpg")
        self.assertTrue(imagesAreEqual(img, expectedImg),
                        "scaled image's pixels are wrong")


    def testResizeAWideImage(self):
        # ImageResize is run on a wide image (1600x240 pixels)
        # the wide image is scaled to be 800x120
        # and it has been scaled by cubic interpolation
        self.fail("test not written")


    def testResizeATallImage(self):
        # ImageResize is run on a very tall image (320x1200 pixels)
        # the tall image is scaled to be 160x600
        # and it has been scaled by cubic interpolation
        self.fail("test not written")


    def testSmallImagesShouldNotBeResized(self):
        # ImageResize is run on a file of exactly 800x600 pixels
        # this image should not have been resized at all
        # (its dateStamp should be older than a minute ago)
        self.fail("test not written")


# next: implement outstanding acceptance test methods

if __name__ == "__main__":
    suite = makeSuite(AcceptanceTest1)
    TextTestRunner().run(suite)
