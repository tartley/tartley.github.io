
from sys import argv


def main(args):
    if len(args) == 2:
        ImageShrinker().shrink(args[1])
    else:
       print "USAGE: python ImageResize.py <imageFilename>"


if __name__=="__main__":
    main(argv)
