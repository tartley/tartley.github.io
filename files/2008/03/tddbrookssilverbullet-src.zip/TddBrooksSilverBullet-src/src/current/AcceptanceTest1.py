import subprocess
import unittest
import PIL
from TestUtils import imagesAreEqual

class AcceptanceTest1(unittest.TestCase):
    """Tests the program ThumbNailer during normal behaviour"""

    def testResizeALargeImage(self):
        # The user invokes ThumbNailer on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ThumbNailer.py TestData/big.jpg
        commandLine = "python ThumbNailer.py TestData/big.jpg"
        subprocess.check_call(commandLine.split())

        # The file big.jpg should be scaled down to 320x240
        img = PIL.Image.open("TestData/big.jpg")
        self.assertEqual(img.size, (320, 240),
                         "image not resized correctly")

        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.
        expectedImg = PIL.Image.open("TestData/expectedResults/big.jpg")
        self.assertTrue(imagesAreEqual(img, expectedImg),
                        "scaled image looks wrong")

# Run this - it's important to see your tests fail
# next: Add further test methods, derived from your specification

if __name__ == "__main__":
    suite = unittest.makeSuite(AcceptanceTest1)
    unittest.TextTestRunner().run(suite)
