
from unittest import makeSuite, TestCase, TextTestRunner
from Shrinker import Shrinker

class ShrinkerUnitTest(TestCase):

    def testCalcNewSizeShouldShrinkTo320x240(self):
        expectedResults = [
             # initial       # expected
            ((32000, 24000), (320, 240)),
            ((1600, 1200),   (320, 240)),
            ((1600, 1000),   (320, 200)),
            ((1600,    2),   (320,   1)),
            ((1400, 1200),   (280, 240)),
            ((   2, 1200),   (  1, 240)),
            (( 320,  240),   (320, 240)),
            ((   1,   1),    (320, 240)),
            ((   0,   0),      (0,   0)),
        ]
        shrinker = Shrinker()
        for initialSize, expectedSize in expectedResults:

            newSize = shrinker.calcNewSize(initialSize)

            self.assertEquals(newSize, expectedSize,
                "size %s->%s, expected %s" % (
                    initialSize, newSize, expectedSize)
                )        


if __name__ == "__main__":
    suite = makeSuite(ShrinkerUnitTest)
    TextTestRunner().run(suite)
