from os import path
import subprocess
from time import time
from unittest import makeSuite, TestCase, TextTestRunner
from PIL import Image, ImageChops
from TestUtils import imagesAreEqual

class AcceptanceTest1(TestCase):
    """Tests the program ThumbNailer during normal behaviour"""

    def invokeThumbNailer(self, filename):
        commandLine = "python ThumbNailer.py TestData/%s" % filename
        subprocess.check_call(commandLine.split())


    def assertImageHasBeenResized(self, filename, expectedSize):
        img = Image.open("TestData/%s" % filename)
        self.assertEqual(img.size, expectedSize,
                         "image %s not resized correctly" % filename)

        expectedFilename = "TestData/expectedResults/%s" % filename
        expectedImg = Image.open(expectedFilename)
        self.assertTrue(imagesAreEqual(img, expectedImg),
                        "scaled image %s looks wrong" % filename)


    # I'll move the above functions to TestUtils.py


    def testResizeALargeImage(self):
        # The user invokes ThumbNailer on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ThumbNailer.py TestData/big.jpg
        self.invokeThumbNailer("big.jpg")

        # The file big.jpg should be scaled down to 320x240
        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.
        self.assertImageHasBeenResized("big.jpg", (320, 240))


    def testResizeAWideImage(self):
        # ThumbNailer is run on a wide image (1600x240 pixels)
        self.invokeThumbNailer("wide.jpg")
        # the wide image is scaled to be 320x48
        # and it has been scaled by cubic interpolation
        self.assertImageHasBeenResized("wide.jpg", (320, 48))


    def testResizeATallImage(self):
        # ThumbNailer is run on a very tall image (320x1200 pixels)
        self.invokeThumbNailer("tall.jpg")
        # the tall image is scaled to be 64x240
        # and it has been scaled by cubic interpolation
        self.assertImageHasBeenResized("tall.jpg", (64, 240))



# next: we have a problem:
# testData files get overwritten by each test method


if __name__ == "__main__":
    suite = makeSuite(AcceptanceTest1)
    TextTestRunner().run(suite)
