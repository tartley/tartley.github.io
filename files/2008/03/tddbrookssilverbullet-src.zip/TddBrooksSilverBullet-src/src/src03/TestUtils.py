
from PIL import ImageChops

def imagesAreEqual(img1, img2):
    """Returns True if img1 and img2 have identical pixel values"""
    difference = ImageChops.difference(img1, img2)
    for pixelNum, rgb in enumerate(difference.getdata()):
        if rgb != (0, 0, 0):
            pixelCoords = (pixelNum % difference.size[0],
                           pixelNum / difference.size[1])
            return False
    return True
