from sys import argv
from PIL import Image

class Shrinker(object):

    def calcNewSize(self, initialSize):
        width, height = initialSize
        xFactor = width / 800.0
        yFactor = height / 600.0
        factor = max(xFactor, yFactor)
        if factor <= 1.0:
            return initialSize
        else:
            newSize = (round(dimension / factor) for dimension in initialSize)
            return tuple(newSize)


    def shrink(self, filename):
        img = Image.open(filename)
        newSize = calcNewSize(initialsize)
        if newSize != initialSize:
            newImg = img.resize(newSize)
            newImg.save(filename)
