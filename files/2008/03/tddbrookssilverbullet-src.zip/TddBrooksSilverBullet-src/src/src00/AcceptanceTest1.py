import unittest

class AcceptanceTest1(unittest.TestCase):
    """Tests the program ThumbNailer during normal behaviour"""

    def testResizeALargeImage(self):
        # The user invokes ThumbNailer on a 982x1196 pixel jpg,
        # using the command line:
        #   python ThumbNailer.py TestData/big.jpg

        # The file big.jpg should be scaled down to 320x240

        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.

        pass # no pun intended


if __name__ == "__main__":
    suite = unittest.makeSuite(AcceptanceTest1)
    unittest.TextTestRunner().run(suite)
