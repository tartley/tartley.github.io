import subprocess
from unittest import makeSuite, TestCase, TextTestRunner
from PIL import Image, ImageChops
from TestUtils import imagesAreEqual

class AcceptanceTest1(TestCase):
    """Tests the program ThumbNailer during normal behaviour"""

    def testResizeALargeImage(self):
        # The user invokes ThumbNailer on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ThumbNailer.py TestData/big.jpg
        commandLine = "python ThumbNailer.py TestData/big.jpg"
        subprocess.check_call(commandLine.split())

        # The file big.jpg should be scaled down to 320x240
        img = Image.open("TestData/big.jpg")
        self.assertEqual(img.size, (320, 240),
                         "image not resized correctly")

        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.
        expectedImg = Image.open("TestData/expectedResults/big.jpg")
        self.assertTrue(imagesAreEqual(img, expectedImg),
                        "scaled image's pixels are wrong")


    def testResizeAWideImage(self):
        # ThumbNailer is run on a wide image (1600x240 pixels)
        # the wide image is scaled to be 320x48
        # and it has been scaled by cubic interpolation
        self.fail("test not written")


    def testResizeATallImage(self):
        # ThumbNailer is run on a very tall image (320x1200 pixels)
        # the tall image is scaled to be 64x240
        # and it has been scaled by cubic interpolation
        self.fail("test not written")


# next: implement these new acceptance test methods

if __name__ == "__main__":
    suite = makeSuite(AcceptanceTest1)
    TextTestRunner().run(suite)
