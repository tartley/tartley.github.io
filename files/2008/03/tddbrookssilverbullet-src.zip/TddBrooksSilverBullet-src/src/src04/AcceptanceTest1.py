from os import listdir, path
from shutil import copy
from time import time
from unittest import makeSuite, TestCase, TextTestRunner
from TestUtils import (
    assertImageHasBeenResized, imagesAreEqual, invokeThumbNailer
)

class AcceptanceTest1(TestCase):
    """Tests the program ThumbNailer during normal behaviour"""

    def setUp(self):
        """setUp is run before every test method"""       
        # restore TestData files from the 'originals' subdirectory
        for filename in listdir("TestData/originals"):
            if filename != '.svn':
                copy("TestData/originals/" + filename, "TestData")
        

    def tearDown(self):
        """tearDown is run after every test method"""
        pass


    def testResizeALargeImage(self):
        # The user invokes ThumbNailer on a 1600x1200 pixel jpg,
        # using the command line:
        #   python ThumbNailer.py TestData/big.jpg
        invokeThumbNailer("big.jpg")

        # The file big.jpg should be scaled down to 320x240
        # It should be scaled using cubic interpolation,
        # so as to prevent aliasing artifacts.
        assertImageHasBeenResized("big.jpg", (320, 240))


    def testResizeAWideImage(self):
        # ThumbNailer is run on a wide image (1600x240 pixels)
        invokeThumbNailer("wide.jpg")
        # the wide image is scaled to be 320x48
        # and it has been scaled by cubic interpolation
        assertImageHasBeenResized("wide.jpg", (320, 48))


    def testResizeATallImage(self):
        # ThumbNailer is run on a very tall image (320x1200 pixels)
        invokeThumbNailer("tall.jpg")
        # the tall image is scaled to be 64x240
        # and it has been scaled by cubic interpolation
        assertImageHasBeenResized("tall.jpg", (64, 240))


if __name__ == "__main__":
    suite = makeSuite(AcceptanceTest1)
    TextTestRunner().run(suite)
