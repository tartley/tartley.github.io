
from subprocess import check_call
from PIL import Image, ImageChops


def imagesAreEqual(img1, img2):
    """Returns True if img1 and img2 have identical pixel values"""
    difference = ImageChops.difference(img1, img2)
    for pixelNum, rgb in enumerate(difference.getdata()):
        if rgb != (0, 0, 0):
            pixelCoords = (pixelNum % difference.size[0],
                           pixelNum / difference.size[1])
            return False
    return True


def invokeThumbNailer(filename):
    commandLine = "python ThumbNailer.py TestData/%s" % filename
    check_call(commandLine.split())


def assertImageHasBeenResized(test, filename, expectedSize):
    img = Image.open("TestData/%s" % filename)
    test.assertEqual(img.size, expectedSize,
                     "image %s not resized correctly" % filename)

    expectedFilename = "TestData/expectedResults/%s" % filename
    expectedImg = Image.open(expectedFilename)
    test.assertTrue(imagesAreEqual(img, expectedImg),
                    "scaled image %s looks wrong" % filename)



