cp -rp src0$1/* current
