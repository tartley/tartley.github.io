
from sys import argv
from PIL import Image

class Shrinker(object):

    def calcNewSize(self, initialSize):
        # This first stab at implementation looks resonable, but contains
        # four bugs. Can you spot them before we re-run the unit test?
        width, height = initialSize
        xFactor = width / 800
        yFactor = height / 600
        factor = max(xFactor, yFactor)
        return (width * factor, height * factor)
