
from sys import argv


def main(args):
    if len(args) == 2:
        ThumbNailer().shrink(args[1])
    else:
       print "USAGE: python ThumbNailer.py <imageFilename>"


if __name__=="__main__":
    main(argv)
