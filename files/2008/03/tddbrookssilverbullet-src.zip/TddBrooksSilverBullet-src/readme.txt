
Test Driven Development: Brooks' Silver Bullet
Presented at PyCon UK, September 2007.


SLIDES:

Are in Open Office format, pycon2007.odp


SOURCE CODE EXAMPLES:

The source code examples in directories s00 to s08 has only been tested on Windows XP and Vista. It represents the state of an example test-driven python project at various stages in development.

However, each directory only contain the files which have changed. To view the project at stage N, therefore, you first start with an empty directory 'src', and then copy all files from src00 to src0N into it. On Windows* you would use something like:

    cd TddBrooksSilverBullet
    xcopy /E /Y src00 src
    xcopy /E /Y src01 src
    etc...
    xcopy /E /Y src0N src


MORE:

For planned but incomplete aspects of the talk, see todo.txt.


LICENSING:

see license.htm



Jonathan Hartley
tartley@tartley.com
