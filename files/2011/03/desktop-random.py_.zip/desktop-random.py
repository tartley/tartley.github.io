#!/usr/bin/python

from os import listdir
from os.path import isfile, splitext
from random import randrange
from subprocess import call
from sys import exit


image_dir = '/home/jhartley/mymedia/images/desktop/'


def get_image_files():
    image_extensions = ['.jpeg', '.jpg', '.png', '.gif', '.bmp']
    files = listdir(image_dir)

    image_files = []
    for file in files:
        ext = splitext(file)[1]
        if ext.lower() in image_extensions and isfile(image_dir + file):
            image_files.append(file)
    return image_files


def pick_one(image_files):
    index = randrange(0, len(image_files))
    return image_files[index]


def set_key(key, value):
    command = [
        'gconftool',
        '-t',
        'string',
        '-s',
        key,
        value,
    ]
    return call(command)


def change_background(image_file):
    root_key = '/desktop/gnome/background/'
    image_key = 'picture_filename'
    options_key = 'picture_options'
    retval = set_key(root_key + image_key, image_dir + image_file)
    if retval == 0:
        retval = set_key(root_key + options_key, "stretched")
    return retval


image_files = get_image_files()
image_file = pick_one(image_files)
print image_file
exit(change_background(image_file))
